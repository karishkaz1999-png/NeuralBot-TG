"""
Конфигурация бота NeuralBot AI Assistant
"""
import os
from dotenv import load_dotenv

load_dotenv()

# Telegram
BOT_TOKEN = os.getenv("BOT_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))

# OpenAI
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
GPT_MODEL = "gpt-4o-mini"  # Экономичная модель с хорошим качеством

# Узбекские платежные системы
CLICK_SERVICE_ID = os.getenv("CLICK_SERVICE_ID", "")
PAYME_MERCHANT_ID = os.getenv("PAYME_MERCHANT_ID", "")

# Реквизиты карты для перевода (Uzcard/Humo)
CARD_NUMBER = os.getenv("CARD_NUMBER", "8600 1234 5678 9012")
CARD_BANK = os.getenv("CARD_BANK", "Uzcard")
CARD_HOLDER = os.getenv("CARD_HOLDER", "IMYA FAMILIYA")

# Pricing (в узбекских сумах)
PRICES = {
    "week": int(os.getenv("PRICE_WEEK", "15000")),
    "month": int(os.getenv("PRICE_MONTH", "39000")),
    "year": int(os.getenv("PRICE_YEAR", "299000")),
}

# Subscription durations in days
DURATIONS = {
    "week": 7,
    "month": 30,
    "year": 365,
}

# Limits
FREE_QUERIES_PER_DAY = int(os.getenv("FREE_QUERIES_PER_DAY", "5"))
REFERRAL_BONUS = int(os.getenv("REFERRAL_BONUS", "10"))

# Database
DATABASE_PATH = "database.db"

# Bot texts
TEXTS = {
    "welcome": """
🤖 <b>Добро пожаловать в NeuralBot!</b>

Я — ваш персональный AI-ассистент на базе ChatGPT.

✨ <b>Что я умею:</b>
• Отвечать на любые вопросы
• Писать тексты, статьи, посты
• Помогать с кодом и программированием
• Переводить на любые языки
• Анализировать и обрабатывать информацию
• Генерировать идеи и креатив

🎁 <b>Бесплатно:</b> {free_queries} запросов в день
💎 <b>Premium:</b> безлимитный доступ

Просто напишите ваш вопрос! 👇
""",
    
    "limit_reached": """
⚠️ <b>Лимит бесплатных запросов исчерпан</b>

Вы использовали все {free_queries} бесплатных запросов на сегодня.

💎 <b>Получите Premium подписку:</b>
• Безлимитные запросы
• Приоритетная обработка
• Доступ к GPT-4

👇 Выберите тариф или пригласите друга и получите +{referral_bonus} запросов!
""",

    "subscription_info": """
💎 <b>Premium подписки NeuralBot</b>

🔹 <b>Неделя</b> — {price_week:,} сум
🔹 <b>Месяц</b> — {price_month:,} сум <i>(выгода 25%)</i>
🔹 <b>Год</b> — {price_year:,} сум <i>(выгода 60%)</i>

✅ Безлимитные запросы
✅ Приоритетная очередь
✅ Расширенные возможности AI
✅ Поддержка 24/7

Выберите подходящий тариф 👇
""",

    "referral_info": """
🎁 <b>Реферальная программа</b>

Приглашай друзей и получай бонусы!

📎 Ваша реферальная ссылка:
<code>{ref_link}</code>

📊 <b>Ваша статистика:</b>
• Приглашено друзей: {ref_count}
• Получено бонусов: {bonus_queries} запросов

За каждого друга — <b>+{referral_bonus} запросов</b>!
""",

    "profile": """
👤 <b>Ваш профиль</b>

🆔 ID: <code>{user_id}</code>
📅 Дата регистрации: {reg_date}

📊 <b>Статистика:</b>
• Всего запросов: {total_queries}
• Осталось сегодня: {remaining}

💎 <b>Подписка:</b> {subscription_status}
{subscription_expires}

👥 Приглашено друзей: {referrals}
""",

    "payment_success": """
✅ <b>Оплата прошла успешно!</b>

Ваша Premium подписка активирована.
Действует до: {expires}

Наслаждайтесь безлимитным доступом! 🚀
""",

    "admin_stats": """
📊 <b>Статистика бота</b>

👥 Всего пользователей: {total_users}
💎 Premium подписчиков: {premium_users}
📨 Запросов сегодня: {today_queries}
💰 Доход за месяц: {monthly_revenue}₽

📈 Новых за сегодня: {new_today}
📈 Новых за неделю: {new_week}
"""
}
